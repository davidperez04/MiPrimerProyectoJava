package EjerciciosPracticosMetodos;

public class Rectangulo {
    float ancho;
    float alto;
}
